import os
import subprocess
import shutil

def install_requirements():
    if not os.path.exists("requirements.txt"):
        print("❌ Файл requirements.txt не найден!")
        return

    print("🚀 Начинаю установку зависимостей...")

    pip_command = "pip3" if shutil.which("pip3") else "pip"

    try:
        subprocess.check_call([pip_command, "install", "-r", "requirements.txt"])
        print(f"✅ Зависимости успешно установлены с помощью {pip_command}!")
    except subprocess.CalledProcessError as e:
        print(f"❌ Ошибка при установке зависимостей: {e}")

if __name__ == "__main__":
    install_requirements()